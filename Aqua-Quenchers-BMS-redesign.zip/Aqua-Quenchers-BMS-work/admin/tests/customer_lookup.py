"""Actual customer lookup/profile/history and absent previous-order UI and immutable business snapshot."""
import argparse
import hashlib
import hmac
import time
import json
import os
import re
import shlex
import subprocess
import ssl
import urllib.request
from connected_android import LOCAL, REPO, PACKAGE, adb, private_json


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--owner', action='store_true')
    options = parser.parse_args()
    c = json.loads((LOCAL / 'private-config.json').read_text())
    assert c['kind'] == 'SYNTHETIC_LOCAL_INTEGRATION_ONLY' and c['url'] == 'https://127.0.0.1:55436'
    assert re.fullmatch(r'aq_http_[0-9a-f]{8}', c['database'])
    assert adb('emu', 'avd', 'name').stdout.decode().splitlines()[0] == 'aq_api29_software'
    assert json.loads((LOCAL / 'own-password-state.json').read_text())['completed'], 'Wait for owned password test to release emulator'
    env = dict(os.environ, LD_LIBRARY_PATH='/workspace/tooling/sysroot/usr/lib/x86_64-linux-gnu')
    def sql(statement): return subprocess.run(['/workspace/tooling/sysroot/usr/lib/postgresql/17/bin/psql', '-X', '-At', '-h', '/workspace/tooling/pgtest', '-p', '55432', '-d', c['database'], '-v', 'ON_ERROR_STOP=1'], input=statement, text=True, capture_output=True, env=env, check=True).stdout.strip()
    snapshot_sql = "select jsonb_build_object(" + ','.join("'" + t + "',(select coalesce(jsonb_agg(to_jsonb(x) order by to_jsonb(x)::text),'[]'::jsonb) from aq_private." + t + ' x)' for t in ['customers', 'orders', 'sales', 'payments', 'expenses', 'inventory', 'reservations', 'profiles']) + ');'
    profiles = json.loads(sql("select jsonb_agg(jsonb_build_object('id',user_id,'username',username)) from aq_private.profiles where role='staff';"))
    ids = json.loads((LOCAL / 'http-test-state.json').read_text()); staff = next(p for p in profiles if p['id'] == ids['staff_id'])
    context = ssl.create_default_context(cafile=c['ca_cert'])
    def call(path, body, token=None):
        req = urllib.request.Request(c['url'] + path, data=json.dumps(body).encode(), headers={'apikey': c['SUPABASE_ANON_KEY'], 'Authorization': 'Bearer ' + (token or c['SUPABASE_ANON_KEY']), 'content-type': 'application/json'})
        with urllib.request.urlopen(req, context=context, timeout=20) as response: return json.load(response)
    username = c['owner_username'] if options.owner else staff['username']
    password = c['owner_password'] if options.owner else c['staff_password']
    # Inspect the owned fixture only. Never reset counters or change source.
    def bucket(kind, value):
        body = json.dumps({kind: value}, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
        return hmac.new(c['SUPABASE_SERVICE_ROLE_KEY'].encode(), body, hashlib.sha256).hexdigest()
    user_bucket, source_bucket = 'u:' + bucket('username', username), 's:' + bucket('source', '127.0.0.1')
    for attempt in range(35):
        delay = int(sql("select coalesce(max(ceil(greatest(0,extract(epoch from started_at+interval '15 minutes'-clock_timestamp()))))::int,0) from aq_private.login_windows where (bucket='" + user_bucket + "' and attempts+2>10) or (bucket='" + source_bucket + "' and attempts+2>60);"))
        if delay == 0: break
        print('Waiting for actual login quota window:', delay, 'seconds; no reset.', flush=True)
        time.sleep(min(30, delay + 1))
    else: raise RuntimeError('Login quota window did not expire; inspect before retry')
    token = call('/functions/v1/username-login', {'username': username, 'password': password})['access_token']
    history_state=json.loads((LOCAL/'customer-edit-owner-host-state.json').read_text());assert history_state['completed']
    history=call('/rest/v1/rpc/aq_query',{'p_request':{'resource':'customer','id':history_state['customer_id']}},token)
    empty_id=sql("select id from aq_private.customers c where not exists(select 1 from aq_private.orders o where o.customer_id=c.id) order by (customer_type='walk_in') desc,id limit 1;")
    assert empty_id, 'Need reviewed no-order synthetic customer; do not invent last quantity'
    empty=call('/rest/v1/rpc/aq_query',{'p_request':{'resource':'customer','id':empty_id}},token)
    assert empty['previous_order_quantity'] is None and len(history['orders'])==1
    detail=call('/rest/v1/rpc/aq_query',{'p_request':{'resource':'order','id':history['orders'][0]['id']}},token)
    date_state=json.loads((LOCAL/('order-date-save-'+('owner' if options.owner else 'staff')+'-state.json')).read_text());assert date_state['completed']
    second=call('/rest/v1/rpc/aq_query',{'p_request':{'resource':'order','id':date_state['verified_order_ids'][0]}},token)
    assert ('timeline' in detail)==options.owner and ('timeline' in second)==options.owner
    fixture={'kind':'SYNTHETIC_LOCAL_CUSTOMER_LOOKUP_UI','username':username,'password':password,'owner':options.owner,'history':history,'empty':empty,'empty_unit':3000 if empty['customer_type']=='dealer' else 3500,'unknown':'NO MATCH '+__import__('uuid').uuid4().hex,'detail':detail,'second_detail':second,'today':sql('select aq_private.today();')}
    private_json(LOCAL / 'customer-lookup-fixture.json', fixture); before = json.loads(sql(snapshot_sql))
    for path in ['app/build/outputs/apk/debug/app-debug.apk', 'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk']: adb('install', '-r', '-t', str(REPO / path))
    adb('reverse', 'tcp:55436', 'tcp:55436')
    adb('shell', 'run-as', PACKAGE, 'sh', '-c', shlex.quote('umask 077; cat > files/customer-lookup-credentials.json'), input=json.dumps(fixture).encode())
    run = adb('shell', 'am', 'instrument', '-w', '-r', '-e', 'class', PACKAGE + '.CustomerLookupDeviceTest', PACKAGE + '.test/androidx.test.runner.AndroidJUnitRunner', timeout=300)
    text = run.stdout.decode().replace(fixture['password'], '[private fixture withheld]'); evidence = REPO / ('evidence/android-customer-lookup-owner.log' if options.owner else 'evidence/android-customer-lookup.log'); evidence.write_text(text)
    assert 'OK (1 test)' in text, 'Inspect native customer-lookup evidence before retry'
    assert json.loads(sql(snapshot_sql)) == before
    adb('shell', 'run-as', PACKAGE, 'rm', 'files/customer-lookup-credentials.json')
    with evidence.open('a') as log: log.write('\nPASS: actual ' + ('Owner' if options.owner else 'Staff') + ' name/contact-with-display-spaces/unknown lookup, exact list/profile balance/status/address/order/receipt fields and navigation, current previous quantity plus absent-history unavailable, fixed-price preview Cancel; historical/current Order detail all customer/date/actor/tracking/money/action fields and Owner-only chronological timeline. All customer/financial/stock/profile records unchanged.\n')
    print('PASS: native customer lookup/profile/history/absent quantity and exact business immutability')


if __name__ == '__main__': main()
